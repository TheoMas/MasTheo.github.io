#include <stdio.h>
#include <iostream>
#include <string>
#include <vector>
#include <limits>

// corrige numero 5, M. Kreyder
//TODO: a completer

using namespace std;
string tabNomPizza[10];
string tabNomIngredients[30];
string tabIngredientsPizzas[10][5];
int tabIngredientQ[30];

string nomClient;
string tabNomClients[40];

int tabCommandeClientsPizzas[40][10]; // les clients peuvent commander jusqu'a 10 pizzas par table
//Verifie si la valeur est conforme
template <typename T>
void checkInput(T& valeur){ //regarde si il y a une entrée / une fonction void n'a pas besoin de return quelque chose
    cin >> valeur;          //lit l'entrée clavier et l'attribue a 'valeur'
    while(cin.fail()){      //permet de voir si l'entrée est correcte, par exemple si on essaie de rentrer un string dans un int, la boucle s'activera
        cin.clear();        //reset l'etat du cin, (enlève l'état de 'fail' du cin)
        cin.ignore(numeric_limits<streamsize>::max(), '\n');        //VIDE LE CIN, la fonction 'ignore' va vider le cin jusqu'a la limite ou jusqu'au premier \n 
                                                                    //(fait un reset de la memoire du cin); l'argument "numeric_limit<streamsize>::max()" est le nombre maximum de caractères que l'on peut donner a un cin
        cout << "valeur incorrecte, veuillez ressayer : ";          
        cin >> valeur;
    }
}

void saisirLesPizzas(){
    tabNomPizza[0] = "QuatreFromages";
    tabNomPizza[1] = "Jambon";
    tabNomPizza[2] = "Brushcetta";
    tabNomPizza[3] = "Ananas";
    tabNomPizza[4] = "Calzone";
    tabNomPizza[5] = "Margarita";
    tabNomPizza[6] = "Saumon";
    tabNomPizza[7] = "Anchois";
    tabNomPizza[8] = "Chorizo";
    tabNomPizza[9] = "Fruits de mer";
}

void afficherPizzas(){
    int i;
    cout<<"liste des pizzas: "<<endl<<endl;
    for(i = 0;i<10;i++){
        cout<<i+1<<" "<<tabNomPizza[i]<< endl;
    };
}

void saisirLesIngredients(){
    int i;

    tabNomIngredients[0] = "Olives";
    tabNomIngredients[1] = "Chevre";
    tabNomIngredients[2] = "Gruyère";
    tabNomIngredients[3] = "Mozzarella";
    tabNomIngredients[4] = "Bleu";
    tabNomIngredients[5] = "Jambon";
    tabNomIngredients[6] = "Sel";
    tabNomIngredients[7] = "Romarin";
    tabNomIngredients[8] = "Salade";
    tabNomIngredients[9] = "Tomate";
    tabNomIngredients[10] = "Vinaigrette";
    tabNomIngredients[11] = "Ananas";
    tabNomIngredients[12]= "Sucre";
    tabNomIngredients[13] = "Champigons";
    tabNomIngredients[14] = "Saumon";
    tabNomIngredients[15] = "Citron";
    tabNomIngredients[16] = "Anchois";
    tabNomIngredients[17] = "Chorizo";
    tabNomIngredients[18] = "Crevettes";
    tabNomIngredients[19] = "Moules";

    for (i=20;i<30;i++){
        tabNomIngredients[i] = "X";
    }

}

void afficherLesIngredients(){
    int i;
    cout<<endl<<"liste des ingredients de la pizzarria:"<<endl<<endl;
    for (i=0;i<30;i++){
        cout<<tabNomIngredients[i]<<endl;
    }
}

void saisirLesQuantiteIngredient(){

    tabIngredientQ[0] = 2; //olives
    tabIngredientQ[1] = 3; //chevre
    tabIngredientQ[2] = 20; //Gruyere
    tabIngredientQ[3] = 10; //Mozzarella
    tabIngredientQ[4] = 0; //Bleu
    tabIngredientQ[5] = 15; //Jambon
    tabIngredientQ[6] = 10; //Sel
    tabIngredientQ[7] = 1; //Romarin
    tabIngredientQ[8] = 2; //Salade
    tabIngredientQ[9] = 2; //Tomate
    tabIngredientQ[10] = 1; //Vinaigrette
    tabIngredientQ[11] = 1; //Ananas
    tabIngredientQ[12] = 1; //Sucre
    tabIngredientQ[13] = 2; //Champignon
    tabIngredientQ[14] = 2; //Saumon
    tabIngredientQ[15] = 1; //Citron
    tabIngredientQ[16] = 2; //Anchois
    tabIngredientQ[17] = 2; //Chorizo
    tabIngredientQ[18] = 2; //Crevettes
    tabIngredientQ[19] = 2; //Moules
}


void attitrerLesIngredientsParPizza(){

    tabIngredientsPizzas[0][0] = "Chevre";
    tabIngredientsPizzas[0][1] = "Gruyere";
    tabIngredientsPizzas[0][2] = "Mozzarella";
    tabIngredientsPizzas[0][3] = "Bleu";
    tabIngredientsPizzas[0][4] = "Chorizo";

    tabIngredientsPizzas[1][0] = "Gruyere";
    tabIngredientsPizzas[1][1] = "Jambon";
    tabIngredientsPizzas[1][2] = "Sel";
    tabIngredientsPizzas[1][3] = "Romarin";
    tabIngredientsPizzas[1][4] = "X";
    
    
    tabIngredientsPizzas[2][0] = "Salade";
    tabIngredientsPizzas[2][1] = "Tomate";
    tabIngredientsPizzas[2][2] = "Mozzarella";
    tabIngredientsPizzas[2][3] = "Vinaigrette";
    tabIngredientsPizzas[2][4] = "X";
    
    tabIngredientsPizzas[3][0] = "Ananas";
    tabIngredientsPizzas[3][1] = "Jambon";
    tabIngredientsPizzas[3][2] = "Sel";
    tabIngredientsPizzas[3][3] = "Sucre";
    tabIngredientsPizzas[3][4] = "X";

    tabIngredientsPizzas[4][0] = "Jambon";
    tabIngredientsPizzas[4][1] = "Mozzarella";
    tabIngredientsPizzas[4][2] = "Gruyere";
    tabIngredientsPizzas[4][3] = "Champigons";
    tabIngredientsPizzas[4][4] = "X";

    tabIngredientsPizzas[5][0] = "Jambon";
    tabIngredientsPizzas[5][1] = "Gruyere";
    tabIngredientsPizzas[5][2] = "Mozzarella";
    tabIngredientsPizzas[5][3] = "Sel";
    tabIngredientsPizzas[5][4] = "X";
    
    tabIngredientsPizzas[6][0] = "Saumon";
    tabIngredientsPizzas[6][1] = "Gruyere";
    tabIngredientsPizzas[6][2] = "Citron";
    tabIngredientsPizzas[6][3] = "Olives";
    tabIngredientsPizzas[6][4] = "X";
    
    tabIngredientsPizzas[7][0] = "Anchois";
    tabIngredientsPizzas[7][1] = "Tomates";
    tabIngredientsPizzas[7][2] = "Olives";
    tabIngredientsPizzas[7][3] = "Sel";
    tabIngredientsPizzas[7][4] = "X";
    
    tabIngredientsPizzas[8][0] = "Chorizo";
    tabIngredientsPizzas[8][1] = "Gruyere";
    tabIngredientsPizzas[8][2] = "Mozzarella";
    tabIngredientsPizzas[8][3] = "Jambon";
    tabIngredientsPizzas[8][4] = "X";
    
    tabIngredientsPizzas[9][0] = "Crevettes";
    tabIngredientsPizzas[9][1] = "Moules";
    tabIngredientsPizzas[9][2] = "Salade";
    tabIngredientsPizzas[9][3] = "Mozzarella";
    tabIngredientsPizzas[9][4] = "X";
}

void afficherIngredientsParPizza(){
    int i,j;
    cout<<endl<<"Ingrédients sur pizza:"<<endl;

    for(i = 0;i<10;i++)
        {
        cout<<endl<<"C'est la pizza "<<tabNomPizza[i]<<" avec les ingredients:"<<endl;
        for(j = 0;j<5;j++)
        {
            cout << tabIngredientsPizzas[i][j] << endl;
        }
    }
}


void afficherPizzaAvecChorizo(){
    int i,j;
    cout<<endl<<"Liste des pizzas avec du chorizo"<<endl;

    for (i=0;i<10;i++){
        for (j = 0; j < 5; j++)
        {
            if (tabIngredientsPizzas[i][j] == "Chorizo"){
                cout<<endl<<"La pizza: "<<tabNomPizza[i]<<" contient du "<< tabIngredientsPizzas[i][j] <<endl;
            }
        }
    }
}

void afficherPizzaIngredient(string ingredientParam){
    int i,j;
    cout<<endl<<"Liste des pizzas avec du "<<ingredientParam<<endl;

    i=0;
    while ((i<10) && (tabIngredientsPizzas[i][j] != ingredientParam)){
        j=0;
        while ((j < 5) && (tabIngredientsPizzas[i][j] != ingredientParam)){
            cout<<endl<<"La pizza: "<<tabNomPizza[i]<<" contient du "<< tabIngredientsPizzas[i][j] <<endl;
        j++;
        }
    i++;
    }
    if (i<10)
    {
        cout<<"La pizza "<<tabNomPizza[i]<<" contient du "<<ingredientParam<<endl;
    }
    else
    {
        cout<<"Pas de pizza avec du "<< ingredientParam<<endl;
    }
}

//int ouPizza(string nomPizzaParam){ //fonction
    //fonction controllant l'existance d'une pizza
    //solution possible avec un bool

  //  int i = 0;
    //bool btrouve = false;

    //while ((i<10) || (btrouve == false)){
      //  if (nompizza[i] == nomPizzaParam){
            //btrouve = true;
        //}
        //else{
        //   i++; //element suivant
        //}
    //}
    //if (btrouve == true){
    //    return (i);
    //}
    //else{
    //    return (i);
    //}
//}

int ouPizza(string nomPizzaParam){ //fonction
    //fonction controllant l'existance d'une pizza
    //solution possible avec un bool

    int i = 0;

    while ((i<10) && (tabNomPizza[i] != nomPizzaParam)){
         i++; //element suivant
    }
    if (i<10){
        return (i);
    }
    else{
        return (-1);
    }
}

int ouIngredient(string nomIngredientParam, int& qteDispo){ //fonction
    //fonction controllant l'existance d'une pizza
    //solution possible avec un bool

    int i = 0;
    bool btrouve = false;

    while ((i<10) && (btrouve == false)){
        if (tabNomPizza[i] == nomIngredientParam){
            btrouve = true;
        }
        else{
            i++; //element suivant
        }
    }
    if (btrouve == true){
        qteDispo = tabIngredientQ[i];
        return (i);
    }
    else{
        qteDispo = 0;
        return (i);
    }
}

//bool commande(string nompizzaparam){
    //recherche si la pizza peut être commandée
//}

bool commande(string nomPizzaParam){
    //On verifie si les ingredients de la pizza sont dispos

    int numPizza;
    int numIngredient;
    bool bContinue = true;
    int j; // permet de parcourir le tableau
    int qte ; //quantite dispo

    numPizza = ouPizza(nomPizzaParam);

    if (numPizza>=0){
        // la pizza a été trouvée
        // parcourir tout le tableau
        j = 0;

        while((j<5) && (bContinue)){
            numIngredient = ouIngredient(tabIngredientsPizzas[numPizza][j], qte);

            if (qte == 0)
            {
                bContinue = false; // pas d'ingredients dispo

            }

            else{
                j++; // on traite l'ingredient suivant
            }
            
        }
    }
    else{
        // je n'ai pas trouvé la pizza
        // indice a -1
        bContinue = false;
    }

    return bContinue;


}

void saisirLesInfos(string& civilite, string& nom, string& prenom, string& rue, string& cpos, string& ville){   
// écrire un & appres le type d'une variable permet de récupérer la variable de base (variable référencée) 
//permet de modifier la variable définie dans une autre fonction (par ex :le main) et de la laisser modifiée même a la fin de la fonction.

    cout <<endl<< "Entrez les coordonnees de la personne :" << endl;

    cout << "civilite : ";
    getline(cin, civilite);

    cout << "nom : ";
    getline(cin, nom);

    cout << "prenom : ";
    getline(cin, prenom);

    cout << "rue : ";
    getline(cin, rue);

    // traitement code postal et ville
    cout << "code postal : ";
    getline(cin, cpos);

    cout << "ville : ";
    getline(cin, ville);
}


void infoClients(string& civilite, string& nom, string& prenom, string& rue, string& cpos, string& ville){
        // Les clients qui commandent les pizzas
    int i;
    int j;
    int numPizza;
    i = 0;


    saisirLesInfos(civilite, nom, prenom, rue, cpos, ville);
    //saisir les clients
    //un client commande pour toute la table

    while ((nom != "F" || "f") && (i<40))
    {
        tabNomClients[i] = nom;
        afficherPizzas();
        cout<<"Saisir le numero de pizza(0 pour arreter)"<< endl;
        cin>>numPizza;
        j=0;
        //Remplir ma commande pour le client
        while ((numPizza>0) && (j<10))
        {
            tabCommandeClientsPizzas[i][j] = numPizza-1;
            //a cause de l'affichage, on decale de 1
            cout<<"Saisir le numero de pizza(0 pour arreter)"<< endl;
            cin>>numPizza;
            j++;

            //Inconvenient : si on commande 3 calzones, il faut la saisir 3 * le 10 (9)
        }
        cout<<"Continuer ?; f pour fin,"<<endl;
        cin>>nom;
        i++;
    }
}

void afficherIngredientsPizza(){
    int i;
    int j;
    string nomPizza;

    cout<<"Choisir la pizza dont vous voulez les Ingrédients"<<endl;
    cin>>nomPizza;
    i = ouPizza(nomPizza);
    for (j = 0; i < 5; j++)
    {
        cout<<"ingredient n°"<<j<<" "<<tabIngredientsPizzas[i][j]<<endl;
    }
}

void lesPizzasDeLaTable(){
    int i,j;
    string pizz;
    cout<<endl<<"De quelle table voulez vous voir la commande?"<<endl;
    cin>>i;

    cout<<"Commande de la table "<<i<<" : "<<endl;
    for(j = 0;j<10;j++)
    {
        pizz = tabNomPizza[tabCommandeClientsPizzas[i][j]];
        cout << pizz << endl;
    }
}

calculPrixDeLaTable(){

}

// retourne le nombre de lignes dans la facture
int calculPrix(double prixpizza[], int quantitepizza[], double& totalprix){ 
//size_t est un type de définition d'entier, utilisé pour les tailles de tableaux/ structures de données 
//vector<> est une structure de données (un tableau)

    // lecture des lignes de la facture
    int i = 0;
    int prix;
    int quantite;


    cout << "Gestion de la facture" << endl;

    cout << "quantite : ";
    checkInput(quantite);

    while (quantite > 0) {

        quantitepizza[i] = quantite;

        cout << "prix de la pizza : ";
        checkInput(prix);   //Dit qu'il va y avoir une entrée et force celle-ci a être valide (renvoie a la fonction du début)
        prixpizza[i] = prix;

        cout << "quantite : ";
        checkInput(quantite);
 
        totalprix += prix * quantite;

        i++;
    }

    cout << "total de la facture : " << totalprix << endl;

    return i ;
}
//Ecriture de la facture
void affFacture(int& j, string& civilite, string& nom, string& prenom, string& rue, string& cpos, string& ville, double& totalprix, int quantitepizza[], double prixpizza[], int& nbreligne){
    // ^ ceci est la signature d'un fonction , elle va definir ce qu'elle return, son nom, et ses paramètres
    //Une fonction ne voit que se qui est a l'interieur d'elle (paramètres :j, civilite, etc...) chaque fonction a une liste de paramètre qu'elle peut voir
    //la valeur de ces paramètres est definie par l'appel de la fonction, dans lequel on va lui donner des variables
    cout << endl;
    cout << "pizza rabbit" << endl;
    cout << endl;
    cout << "numero de commande: " << "23" << endl;
    cout << "Numero de client :" << "234" << endl;
    cout << "                                     " << civilite << " " << nom << " " << prenom << endl;
    cout << "                                     " << rue << endl;
    cout << "                                     " << cpos << " " << ville << endl;
    cout << endl;
    cout << "ligne de la commande " << endl;
    cout << "      quantite" << "    " << "reference" << "    " << "designation" << "  prix    " << "total" << endl;

    for (j = 0; j < nbreligne; j++) {
        cout << "N. " << j + 1 << "  " << quantitepizza[j] << "          " << " ref" << j + 1 << "        " << "nompizza"
             << j + 1;
        cout << "     " << prixpizza[j] << "      " << quantitepizza[j] * prixpizza[j] << endl;
    }

    cout << endl;
    cout << endl;
    cout << "                                                        total: " << totalprix;
}

char afficheMenu(){  //Permet de gerer le menu
    char choix;

    cout<<"MENU PRINCIPAL DE GESTION"<<endl<<endl;

    cout<<"1 : affiche les pizzas"<<endl;
    cout<<"2 : afficher les ingredients de la pizza choisie"<<endl;
    cout<<"3 : saisir les pizzas de la table"<<endl;
    cout<<"4 : calculer l'addition de la table/commande"<<endl;

    //autre cout

    cout<<"F pour fin"<<endl;
    cout<<"Quel est votre choix?"<<endl;
    cin>>choix;
    return (choix);
}

void gestionPizzeria(){  // permet de gerer la pizzeria
    
    char chMenu; // choix du menu
    chMenu = afficheMenu(); // je recupere le choix

//    while(chMenu != 'F')
//        if chMenu == 1
//            afficherPizzas();
//        else if chMenu == 2
//            afficherLesIngredients();
    while (chMenu != 'F')
    {
        switch (chMenu)
        {
        case '1':
            afficherPizzas();
            break;
        case '2':
            afficherIngredientsPizza();  // pour une pizza
            break;
        case '3':
            lesPizzasDeLaTable();
            break;
        case '4':
            calculPrixDeLaTable(); //addition pour une table
            break;
        default:
            cout<<"cas invalide"<<endl;
        }
        
        chMenu = afficheMenu();
    }
    
}

// programme principal
int main(){
    //int i;
    int j; // permet l'affichage des lignes de la facture de la pizza
    string civilite;
    string nom;
    string prenom;
    string rue;
    string cpos;
    string ville;
    double totalprix;
    //int quantite;
    string nompizzaparam;
    int quantitepizza[10];
    double prixpizza[10];
    int nbreligne; // nombre de lignes dans la commande
    //int indice;
    string ingredientDemande;
    //int numPizza;
    string nomClient;
        // début du programme
    //saisir le nom des pizzas
    saisirLesPizzas();
    //ecrire les noms des pizzas saisis précédement
    //afficherPizzas();

    //saisir le nom des ingrédients
    saisirLesIngredients();
    //ecrire le nom des ingrédients saisis précédement
    //afficherLesIngredients();

    //tableau a deux dimensions qui donnes les ingrédients par pizza
    attitrerLesIngredientsParPizza();
    //affichage des nom de chaque pizza ainsi que ces ingrédients
    //afficherIngredientsParPizza();
    infoClients(civilite, nom, prenom, rue, cpos, ville);
    //PREVOIR UN MENU GESTION POUR LE CAISSIER
    gestionPizzeria();

    //cin>>ingredientDemande;

    //afficherPizzaIngredient(ingredientDemande);

    /*
    indice = ouPizza("Calzone");
    cout<<endl;
    cout<<"pizza Calzone , a l'indice : "<<indice;
    cout<<endl; 

    indice = ouIngredient("Tomate", quantite);
    cout<<endl;
    cout<<"L'ingredient Tomate , a l'indice : "<<indice;
    cout<<endl; 

    nompizzaparam = "Calzone";
 
    if(commande(nompizzaparam)){ // fonction booléenne
    cout<<"Vous pouvez commander la pizza : "<<nompizzaparam;
    }
    else{
        cout<<"pas de pizza : "<<nompizzaparam<<endl;
    }
    */
    //Client
    //saisirLesInfos(civilite, nom, prenom, rue, cpos, ville);

    // on va calculer et sauvegarder le nombre de lignes
    nbreligne = calculPrix(prixpizza, quantitepizza, totalprix);   //donne des variables, données en tant que paramètres pour la fonction (remplit les paramètres de la fonction a l'aide des variables qui lui sont données)

    //TODO: reste a mettre en forme la presentation de la facture
    affFacture(j,civilite, nom, prenom, rue, cpos, ville, totalprix, quantitepizza, prixpizza, nbreligne);  //affichage definitif de la pizza
    // Les clients qui commandent les pizzas
    /*
    i = 0;


    cout<<"Donnez le nom des clients; f pour fin"<<endl;
    cin>>nomClient;
    //saisir les clients
    //un client commande pour toute la table

    while ((nomClient != "F" || "f") && (i<40))
    {
        tabNomClients[i] = nomClient;
        afficherPizzas();
        cout<<"Saisir le numero de pizza(0 pour arreter)"<< endl;
        cin>>numPizza;
        j=0;
        //Remplir ma commande pour le client
        while ((numPizza>0) && (j<10))
        {
            tabCommandeClientsPizzas[i][j] = numPizza-1;
            //a cause de l'affichage, on decale de 1
            cout<<"Saisir le numero de pizza(0 pour arreter)"<< endl;
            cin>>numPizza;
            j++;

            //Inconvenient : si on commande 3 calzones, il faut la saisir 3 * le 10 (9)
        }
        cout<<"Donnez le nom des clients; f pour fin"<<endl;
        cin>>nomClient;
        i++;
    }
    */
}


